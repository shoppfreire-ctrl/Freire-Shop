export interface Category {
  id: string
  name: string
  description: string
  icon: string
  /** Categoria só com estrutura, sem produtos ainda. */
  comingSoon?: boolean
}

export interface Product {
  id: string
  name: string
  categoryId: string
  description: string
  /** Preço em reais. */
  price: number
  /** Preço promocional opcional (precisa ser menor que `price`). */
  promoPrice?: number
  /** Caminho da imagem, ex.: "/products/cortador.jpg" (arquivo em /public/products). */
  image?: string
  /** Estoque, somente quando você souber o número real. */
  stock?: number
  available: boolean
  isNew?: boolean
  featured?: boolean
  /** Marca o item como dado de demonstração. Remova ao cadastrar produto real. */
  demo?: boolean
}

export interface CartEntry {
  id: string
  qty: number
}

export interface CartLine {
  product: Product
  qty: number
  unitPrice: number
  total: number
  maxQty: number
}
