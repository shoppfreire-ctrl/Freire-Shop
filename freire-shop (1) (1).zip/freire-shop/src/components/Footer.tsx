import { Link } from 'react-router-dom'
import { isPending, storeConfig, whatsappReady } from '../config/store'
import { infoPages } from '../data/pages'

export default function Footer() {
  const c = storeConfig.contact
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <p className="footer-brand">{storeConfig.name}</p>
          <p>{storeConfig.slogan}</p>
          <p className="muted-light">{storeConfig.region}</p>
        </div>
        <div>
          <p className="footer-title">Institucional</p>
          <ul className="plain">
            {infoPages.map((p) => (
              <li key={p.slug}><Link to={`/pagina/${p.slug}`}>{p.title}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <p className="footer-title">Contato</p>
          <ul className="plain">
            <li>WhatsApp: {whatsappReady() ? 'disponível ao finalizar o pedido' : 'a configurar'}</li>
            <li>E-mail: {isPending(c.email) ? 'a configurar' : c.email}</li>
            <li>Instagram: {isPending(c.instagram) ? 'a configurar' : c.instagram}</li>
            <li>Atendimento: {isPending(c.hours) ? 'a configurar' : c.hours}</li>
          </ul>
        </div>
      </div>
      <div className="container footer-legal">
        <p>
          © {new Date().getFullYear()} {isPending(storeConfig.business.legalName) ? storeConfig.name : storeConfig.business.legalName}
          {isPending(storeConfig.business.document) ? '' : ` — ${storeConfig.business.document}`}
        </p>
        <p>Produtos, preços e imagens atuais são demonstrações. Preços, frete e disponibilidade são confirmados com a loja.</p>
      </div>
    </footer>
  )
}
