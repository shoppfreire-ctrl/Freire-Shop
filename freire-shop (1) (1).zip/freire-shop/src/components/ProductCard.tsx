import { Link } from 'react-router-dom'
import { maxQtyFor, useCart } from '../context/CartContext'
import type { Product } from '../types'
import Price from './Price'
import ProductImage from './ProductImage'

export default function ProductCard({ product }: { product: Product }) {
  const { add, lines } = useCart()
  const inCart = lines.find((l) => l.product.id === product.id)?.qty ?? 0
  const max = maxQtyFor(product)
  const canAdd = product.available && inCart < max

  return (
    <article className="card">
      <Link to={`/produto/${product.id}`} className="card-media" aria-label={`Ver ${product.name}`}>
        <ProductImage product={product} />
        {product.isNew && <span className="tag tag-new">Novo</span>}
      </Link>
      <div className="card-body">
        <h3 className="card-title"><Link to={`/produto/${product.id}`}>{product.name}</Link></h3>
        <Price product={product} />
        {!product.available && <p className="muted">Indisponível</p>}
        <div className="card-actions">
          <Link to={`/produto/${product.id}`} className="btn btn-ghost">Ver produto</Link>
          <button className="btn btn-primary" disabled={!canAdd} onClick={() => add(product.id)}>
            {!product.available ? 'Indisponível' : inCart >= max ? 'Limite atingido' : 'Adicionar'}
          </button>
        </div>
      </div>
    </article>
  )
}
