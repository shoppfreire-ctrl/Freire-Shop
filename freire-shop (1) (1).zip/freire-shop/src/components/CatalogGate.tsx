import type { ReactNode } from 'react'
import { useCatalog } from '../context/CatalogContext'
import StatusMessage from './StatusMessage'

/** Mostra carregamento/erro antes de exibir o conteúdo que depende do catálogo. */
export default function CatalogGate({ children }: { children: ReactNode }) {
  const { status, reload } = useCatalog()
  if (status === 'loading') return <StatusMessage title="Carregando produtos…" />
  if (status === 'error') {
    return (
      <StatusMessage
        title="Não foi possível carregar os produtos"
        action={<button className="btn btn-primary" onClick={reload}>Tentar novamente</button>}
      >
        Verifique sua conexão e tente de novo.
      </StatusMessage>
    )
  }
  return <>{children}</>
}
