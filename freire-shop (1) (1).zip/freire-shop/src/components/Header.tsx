import { useState, type FormEvent } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { storeConfig } from '../config/store'
import { useCart } from '../context/CartContext'
import { useCatalog } from '../context/CatalogContext'

export default function Header() {
  const { count } = useCart()
  const { categories } = useCatalog()
  const navigate = useNavigate()
  const [query, setQuery] = useState('')

  function onSearch(e: FormEvent) {
    e.preventDefault()
    const q = query.trim()
    navigate(q ? `/produtos?busca=${encodeURIComponent(q)}` : '/produtos')
  }

  return (
    <header className="header">
      <a href="#conteudo" className="skip">Ir para o conteúdo</a>
      <div className="container header-row">
        <Link to="/" className="logo" aria-label={`${storeConfig.name} — página inicial`}>
          <span className="logo-mark" aria-hidden="true">F</span>
          <span className="logo-text">Freire<b>Shop</b></span>
        </Link>
        <form className="search" role="search" onSubmit={onSearch}>
          <label htmlFor="busca" className="sr-only">Pesquisar produtos</label>
          <input id="busca" type="search" placeholder="Buscar produtos" value={query} onChange={(e) => setQuery(e.target.value)} />
          <button type="submit" className="btn btn-lime" aria-label="Pesquisar">Buscar</button>
        </form>
        <Link to="/carrinho" className="cart-link" aria-label={`Carrinho, ${count} ${count === 1 ? 'item' : 'itens'}`}>
          <span aria-hidden="true">🛒</span>
          <span className="cart-badge" aria-hidden="true">{count}</span>
        </Link>
      </div>
      <nav className="catnav" aria-label="Categorias">
        <div className="container catnav-row">
          <NavLink to="/produtos" end className="catnav-link">Todos</NavLink>
          {categories.map((c) => (
            <Link key={c.id} to={`/produtos?categoria=${c.id}`} className="catnav-link">{c.name}</Link>
          ))}
        </div>
      </nav>
    </header>
  )
}
