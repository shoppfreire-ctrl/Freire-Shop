import { formatBRL, hasPromo } from '../lib/format'
import type { Product } from '../types'

export default function Price({ product }: { product: Product }) {
  if (hasPromo(product)) {
    return (
      <p className="price">
        <s className="price-old"><span className="sr-only">Preço original </span>{formatBRL(product.price)}</s>
        <strong className="price-now"><span className="sr-only">Preço promocional </span>{formatBRL(product.promoPrice as number)}</strong>
      </p>
    )
  }
  return <p className="price"><strong className="price-now">{formatBRL(product.price)}</strong></p>
}
