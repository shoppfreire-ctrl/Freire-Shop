import { useState } from 'react'
import { useCatalog } from '../context/CatalogContext'
import type { Product } from '../types'

export default function ProductImage({ product, eager = false }: { product: Product; eager?: boolean }) {
  const { getCategory } = useCatalog()
  const [failed, setFailed] = useState(false)
  const icon = getCategory(product.categoryId)?.icon ?? '🛍️'

  if (product.image && !failed) {
    return (
      <div className="pimg">
        <img src={product.image} alt={product.name} loading={eager ? 'eager' : 'lazy'} decoding="async" width={400} height={400} onError={() => setFailed(true)} />
        {product.demo && <span className="tag tag-demo">Demonstração</span>}
      </div>
    )
  }
  return (
    <div className="pimg pimg-placeholder" role="img" aria-label={`Imagem ilustrativa de ${product.name}`}>
      <span className="pimg-icon" aria-hidden="true">{icon}</span>
      <span className="pimg-note">Imagem ilustrativa</span>
      {product.demo && <span className="tag tag-demo">Demonstração</span>}
    </div>
  )
}
