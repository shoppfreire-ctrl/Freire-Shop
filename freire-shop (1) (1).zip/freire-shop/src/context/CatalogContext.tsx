import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { fetchCatalog } from '../lib/catalog'
import type { Category, Product } from '../types'

type Status = 'loading' | 'ready' | 'error'

interface CatalogValue {
  products: Product[]
  categories: Category[]
  status: Status
  reload: () => void
  getProduct: (id: string) => Product | undefined
  getCategory: (id: string) => Category | undefined
}

const CatalogContext = createContext<CatalogValue | null>(null)

export function CatalogProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [status, setStatus] = useState<Status>('loading')
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    let active = true
    setStatus('loading')
    fetchCatalog()
      .then((c) => {
        if (!active) return
        setProducts(c.products)
        setCategories(c.categories)
        setStatus('ready')
      })
      .catch(() => active && setStatus('error'))
    return () => {
      active = false
    }
  }, [attempt])

  const reload = useCallback(() => setAttempt((a) => a + 1), [])

  const value = useMemo<CatalogValue>(
    () => ({
      products,
      categories,
      status,
      reload,
      getProduct: (id) => products.find((p) => p.id === id),
      getCategory: (id) => categories.find((c) => c.id === id),
    }),
    [products, categories, status, reload],
  )

  return <CatalogContext.Provider value={value}>{children}</CatalogContext.Provider>
}

export function useCatalog() {
  const ctx = useContext(CatalogContext)
  if (!ctx) throw new Error('useCatalog precisa estar dentro de CatalogProvider')
  return ctx
}
