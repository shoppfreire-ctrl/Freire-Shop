import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { unitPrice } from '../lib/format'
import type { CartEntry, CartLine, Product } from '../types'
import { useCatalog } from './CatalogContext'

const STORAGE_KEY = 'freire-shop-cart-v1'
const MAX_QTY = 99

export const maxQtyFor = (p: Product) =>
  p.available ? (typeof p.stock === 'number' ? Math.max(0, Math.min(p.stock, MAX_QTY)) : MAX_QTY) : 0

function loadEntries(): CartEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const data: unknown = JSON.parse(raw)
    if (!Array.isArray(data)) return []
    return data
      .filter(
        (e): e is CartEntry =>
          typeof e === 'object' && e !== null && typeof (e as CartEntry).id === 'string' &&
          Number.isInteger((e as CartEntry).qty) && (e as CartEntry).qty > 0,
      )
      .map((e) => ({ id: e.id, qty: Math.min(e.qty, MAX_QTY) }))
  } catch {
    return []
  }
}

interface CartValue {
  lines: CartLine[]
  count: number
  subtotal: number
  add: (id: string) => void
  setQty: (id: string, qty: number) => void
  remove: (id: string) => void
  clear: () => void
}

const CartContext = createContext<CartValue | null>(null)

export function CartProvider({ children }: { children: ReactNode }) {
  const { getProduct, status } = useCatalog()
  const [entries, setEntries] = useState<CartEntry[]>(loadEntries)

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(entries))
    } catch {
      /* armazenamento indisponível: o carrinho funciona só nesta sessão */
    }
  }, [entries])

  const setQty = useCallback(
    (id: string, qty: number) => {
      const product = getProduct(id)
      if (!product) return
      const safe = Number.isFinite(qty) ? Math.floor(qty) : 0
      const clamped = Math.min(safe, maxQtyFor(product))
      setEntries((prev) => {
        if (clamped <= 0) return prev.filter((e) => e.id !== id)
        if (prev.some((e) => e.id === id)) return prev.map((e) => (e.id === id ? { ...e, qty: clamped } : e))
        return [...prev, { id, qty: clamped }]
      })
    },
    [getProduct],
  )

  const add = useCallback(
    (id: string) => {
      const product = getProduct(id)
      if (!product || maxQtyFor(product) < 1) return
      setEntries((prev) => {
        const current = prev.find((e) => e.id === id)?.qty ?? 0
        const next = Math.min(current + 1, maxQtyFor(product))
        if (current === 0) return [...prev, { id, qty: next }]
        return prev.map((e) => (e.id === id ? { ...e, qty: next } : e))
      })
    },
    [getProduct],
  )

  const remove = useCallback((id: string) => setEntries((prev) => prev.filter((e) => e.id !== id)), [])
  const clear = useCallback(() => setEntries([]), [])

  const lines = useMemo<CartLine[]>(() => {
    if (status !== 'ready') return []
    const result: CartLine[] = []
    for (const e of entries) {
      const product = getProduct(e.id)
      const max = product ? maxQtyFor(product) : 0
      if (!product || max < 1) continue
      const qty = Math.min(e.qty, max)
      const price = unitPrice(product)
      result.push({ product, qty, unitPrice: price, total: Math.round(price * qty * 100) / 100, maxQty: max })
    }
    return result
  }, [entries, getProduct, status])

  const value = useMemo<CartValue>(
    () => ({
      lines,
      count: lines.reduce((s, l) => s + l.qty, 0),
      subtotal: Math.round(lines.reduce((s, l) => s + l.total, 0) * 100) / 100,
      add,
      setQty,
      remove,
      clear,
    }),
    [lines, add, setQty, remove, clear],
  )

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart precisa estar dentro de CartProvider')
  return ctx
}
