import { Link, useParams } from 'react-router-dom'
import CatalogGate from '../components/CatalogGate'
import Price from '../components/Price'
import ProductImage from '../components/ProductImage'
import StatusMessage from '../components/StatusMessage'
import { maxQtyFor, useCart } from '../context/CartContext'
import { useCatalog } from '../context/CatalogContext'
import { usePageMeta } from '../lib/usePageMeta'

function Detail({ id }: { id: string }) {
  const { getProduct, getCategory } = useCatalog()
  const { add, lines } = useCart()
  const product = getProduct(id)
  usePageMeta(product?.name, product?.description)

  if (!product) {
    return (
      <StatusMessage title="Produto não encontrado" action={<Link className="btn btn-primary" to="/produtos">Ver todos os produtos</Link>}>
        O link pode estar errado ou o produto foi removido.
      </StatusMessage>
    )
  }

  const category = getCategory(product.categoryId)
  const inCart = lines.find((l) => l.product.id === product.id)?.qty ?? 0
  const max = maxQtyFor(product)
  const canAdd = product.available && inCart < max

  return (
    <div className="container section detail">
      <p className="breadcrumb">
        <Link to="/produtos">Produtos</Link>
        {category && <> / <Link to={`/produtos?categoria=${category.id}`}>{category.name}</Link></>}
      </p>
      <div className="detail-grid">
        <ProductImage product={product} eager />
        <div>
          <h1>{product.name}</h1>
          <Price product={product} />
          <p className={product.available ? 'avail ok' : 'avail no'}>
            {product.available ? 'Disponível' : 'Indisponível'}
            {typeof product.stock === 'number' && product.available ? ` · ${product.stock} em estoque` : ''}
          </p>
          <p>{product.description}</p>
          {product.demo && <p className="note">Produto de demonstração: preço, descrição e imagem são apenas exemplos.</p>}
          <p className="muted">Frete e disponibilidade de entrega são confirmados com a loja.</p>
          <div className="detail-actions">
            <button className="btn btn-primary btn-lg" disabled={!canAdd} onClick={() => add(product.id)}>
              {!product.available ? 'Indisponível' : inCart >= max ? 'Limite atingido' : 'Adicionar ao carrinho'}
            </button>
            {inCart > 0 && <Link to="/carrinho" className="btn btn-ghost btn-lg">Ver carrinho ({inCart})</Link>}
          </div>
        </div>
      </div>
    </div>
  )
}

export default function ProductPage() {
  const { id = '' } = useParams()
  return <CatalogGate><Detail id={id} /></CatalogGate>
}
