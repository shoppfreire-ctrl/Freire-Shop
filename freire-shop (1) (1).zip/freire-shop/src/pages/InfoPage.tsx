import { Link, useParams } from 'react-router-dom'
import StatusMessage from '../components/StatusMessage'
import { isPending, storeConfig, whatsappReady } from '../config/store'
import { infoPages } from '../data/pages'
import { usePageMeta } from '../lib/usePageMeta'

export default function InfoPage() {
  const { slug = '' } = useParams()
  const page = infoPages.find((p) => p.slug === slug)
  usePageMeta(page?.title, page?.description)

  if (!page) {
    return (
      <div className="container section">
        <StatusMessage title="Página não encontrada" action={<Link className="btn btn-primary" to="/">Voltar ao início</Link>} />
      </div>
    )
  }

  const c = storeConfig.contact
  return (
    <div className="container section prose">
      <h1>{page.title}</h1>
      {page.sections.map((s) => (
        <section key={s.heading}>
          <h2>{s.heading}</h2>
          <p>{s.body}</p>
        </section>
      ))}
      {page.slug === 'contato' && (
        <ul>
          <li>WhatsApp: {whatsappReady() ? 'use o botão de finalizar pedido no carrinho' : 'a configurar'}</li>
          <li>E-mail: {isPending(c.email) ? 'a configurar' : c.email}</li>
          <li>Instagram: {isPending(c.instagram) ? 'a configurar' : c.instagram}</li>
          <li>Endereço: {isPending(c.address) ? 'a configurar' : c.address}</li>
          <li>Horário: {isPending(c.hours) ? 'a configurar' : c.hours}</li>
        </ul>
      )}
    </div>
  )
}
