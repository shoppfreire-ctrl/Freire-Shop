import { Link } from 'react-router-dom'
import CatalogGate from '../components/CatalogGate'
import ProductGrid from '../components/ProductGrid'
import { storeConfig } from '../config/store'
import { useCatalog } from '../context/CatalogContext'
import { hasPromo } from '../lib/format'
import { usePageMeta } from '../lib/usePageMeta'

const benefits = [
  { title: 'Pedido pelo WhatsApp', text: 'Monte o carrinho aqui e combine tudo direto com a loja.' },
  { title: 'Produtos do dia a dia', text: 'Itens úteis para casa, cozinha, carro e pequenas soluções.' },
  { title: 'Atendimento local', text: `Pensada para ${storeConfig.region}.` },
  { title: 'Sem surpresa no total', text: 'Frete e disponibilidade são confirmados antes de fechar.' },
]

function HomeContent() {
  const { products, categories } = useCatalog()
  const featured = products.filter((p) => p.featured).slice(0, 4)
  const news = products.filter((p) => p.isNew).slice(0, 4)
  const offers = products.filter(hasPromo).slice(0, 4)

  return (
    <>
      <section className="hero">
        <div className="container hero-inner">
          <h1>{storeConfig.slogan}</h1>
          <p>Achados úteis e acessíveis para facilitar a rotina. Escolha, monte o carrinho e finalize pelo WhatsApp.</p>
          <div className="hero-actions">
            <Link to="/produtos" className="btn btn-lime btn-lg">Ver produtos</Link>
            <Link to="/produtos?novidades=1" className="btn btn-outline btn-lg">Ver novidades</Link>
          </div>
        </div>
      </section>

      <section className="container section" aria-labelledby="h-cats">
        <h2 id="h-cats">Categorias</h2>
        <div className="cat-grid">
          {categories.map((c) => (
            <Link key={c.id} to={`/produtos?categoria=${c.id}`} className="cat-card">
              <span className="cat-icon" aria-hidden="true">{c.icon}</span>
              <span className="cat-name">{c.name}</span>
              <span className="cat-desc">{c.comingSoon ? 'Em breve' : c.description}</span>
            </Link>
          ))}
        </div>
      </section>

      {offers.length > 0 && (
        <section className="container section" aria-labelledby="h-offers">
          <h2 id="h-offers">Ofertas</h2>
          <ProductGrid products={offers} />
        </section>
      )}

      {featured.length > 0 && (
        <section className="container section" aria-labelledby="h-feat">
          <h2 id="h-feat">Produtos em destaque</h2>
          <ProductGrid products={featured} />
        </section>
      )}

      {news.length > 0 && (
        <section className="container section" aria-labelledby="h-news">
          <div className="section-head">
            <h2 id="h-news">Novidades</h2>
            <Link to="/produtos?novidades=1">Ver todas</Link>
          </div>
          <ProductGrid products={news} />
        </section>
      )}

      <section className="benefits" aria-labelledby="h-ben">
        <div className="container section">
          <h2 id="h-ben">Por que comprar na {storeConfig.name}</h2>
          <ul className="benefit-grid plain">
            {benefits.map((b) => (
              <li key={b.title} className="benefit">
                <h3>{b.title}</h3>
                <p>{b.text}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  )
}

export default function Home() {
  usePageMeta()
  return <CatalogGate><HomeContent /></CatalogGate>
}
