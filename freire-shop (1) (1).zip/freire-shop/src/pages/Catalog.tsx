import { useMemo } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import CatalogGate from '../components/CatalogGate'
import ProductGrid from '../components/ProductGrid'
import StatusMessage from '../components/StatusMessage'
import { useCatalog } from '../context/CatalogContext'
import { normalize, unitPrice } from '../lib/format'
import { usePageMeta } from '../lib/usePageMeta'

function CatalogContent() {
  const { products, categories } = useCatalog()
  const [params, setParams] = useSearchParams()
  const busca = params.get('busca') ?? ''
  const categoria = params.get('categoria') ?? ''
  const ordem = params.get('ordem') ?? ''
  const novidades = params.get('novidades') === '1'

  function update(key: string, value: string) {
    const next = new URLSearchParams(params)
    if (value) next.set(key, value)
    else next.delete(key)
    setParams(next, { replace: true })
  }

  const activeCategory = categories.find((c) => c.id === categoria)

  const list = useMemo(() => {
    const q = normalize(busca)
    const filtered = products.filter(
      (p) =>
        (!categoria || p.categoryId === categoria) &&
        (!novidades || p.isNew) &&
        (!q || normalize(p.name).includes(q)),
    )
    if (ordem === 'menor') return [...filtered].sort((a, b) => unitPrice(a) - unitPrice(b))
    if (ordem === 'maior') return [...filtered].sort((a, b) => unitPrice(b) - unitPrice(a))
    return filtered
  }, [products, busca, categoria, novidades, ordem])

  const hasFilters = Boolean(busca || categoria || novidades || ordem)

  return (
    <div className="container section">
      <h1>{activeCategory ? activeCategory.name : 'Todos os produtos'}</h1>
      {busca && <p className="muted">Resultados para “{busca}”</p>}

      <div className="filters">
        <div className="field">
          <label htmlFor="f-busca">Nome do produto</label>
          <input id="f-busca" type="search" value={busca} onChange={(e) => update('busca', e.target.value)} placeholder="Ex.: cortador" />
        </div>
        <div className="field">
          <label htmlFor="f-cat">Categoria</label>
          <select id="f-cat" value={categoria} onChange={(e) => update('categoria', e.target.value)}>
            <option value="">Todas</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div className="field">
          <label htmlFor="f-ordem">Ordenar por</label>
          <select id="f-ordem" value={ordem} onChange={(e) => update('ordem', e.target.value)}>
            <option value="">Padrão</option>
            <option value="menor">Menor preço</option>
            <option value="maior">Maior preço</option>
          </select>
        </div>
        <label className="check">
          <input type="checkbox" checked={novidades} onChange={(e) => update('novidades', e.target.checked ? '1' : '')} />
          Só novidades
        </label>
      </div>

      <p className="muted" aria-live="polite">{list.length} {list.length === 1 ? 'produto' : 'produtos'}</p>

      {list.length > 0 ? (
        <ProductGrid products={list} />
      ) : activeCategory?.comingSoon && !busca && !novidades ? (
        <StatusMessage title="Em breve">A categoria {activeCategory.name} ainda não tem produtos. Volte em breve.</StatusMessage>
      ) : (
        <StatusMessage
          title="Nenhum produto encontrado"
          action={hasFilters ? <Link className="btn btn-primary" to="/produtos">Limpar filtros</Link> : undefined}
        >
          {hasFilters ? 'Tente outro nome ou remova algum filtro.' : 'O catálogo ainda está vazio.'}
        </StatusMessage>
      )}
    </div>
  )
}

export default function Catalog() {
  usePageMeta('Produtos', 'Veja os produtos da Freire Shop, pesquise por nome e filtre por categoria.')
  return <CatalogGate><CatalogContent /></CatalogGate>
}
