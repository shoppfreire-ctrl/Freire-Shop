import { Link } from 'react-router-dom'
import StatusMessage from '../components/StatusMessage'
import { usePageMeta } from '../lib/usePageMeta'

export default function NotFound() {
  usePageMeta('Página não encontrada')
  return (
    <div className="container section">
      <StatusMessage title="Página não encontrada" action={<Link className="btn btn-primary" to="/">Voltar ao início</Link>}>
        O endereço pode estar incorreto.
      </StatusMessage>
    </div>
  )
}
