import { useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'
import CatalogGate from '../components/CatalogGate'
import ProductImage from '../components/ProductImage'
import StatusMessage from '../components/StatusMessage'
import { storeConfig, whatsappReady } from '../config/store'
import { useCart } from '../context/CartContext'
import { formatBRL } from '../lib/format'
import { usePageMeta } from '../lib/usePageMeta'
import { buildOrderMessage, buildWhatsAppUrl } from '../lib/whatsapp'

function CartContent() {
  const { lines, subtotal, setQty, remove, clear } = useCart()
  // Dados do cliente ficam só na memória desta tela: não são salvos em lugar nenhum.
  const [name, setName] = useState('')
  const [city, setCity] = useState('')
  const [address, setAddress] = useState('')
  const [error, setError] = useState('')
  const ready = whatsappReady()

  if (lines.length === 0) {
    return (
      <StatusMessage title="Seu carrinho está vazio" action={<Link className="btn btn-primary" to="/produtos">Ver produtos</Link>}>
        Adicione produtos para montar seu pedido.
      </StatusMessage>
    )
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!name.trim() || !city.trim()) {
      setError('Informe seu nome e a cidade de entrega.')
      return
    }
    const url = buildWhatsAppUrl(buildOrderMessage(lines, { name, city, address }))
    if (!url) {
      setError('O WhatsApp da loja ainda não foi configurado.')
      return
    }
    setError('')
    window.open(url, '_blank', 'noopener,noreferrer')
  }

  return (
    <div className="cart-layout">
      <ul className="plain cart-list">
        {lines.map((l) => (
          <li key={l.product.id} className="cart-item">
            <div className="cart-thumb"><ProductImage product={l.product} /></div>
            <div className="cart-info">
              <Link to={`/produto/${l.product.id}`} className="cart-name">{l.product.name}</Link>
              <p className="muted">{formatBRL(l.unitPrice)} cada</p>
              <div className="qty" role="group" aria-label={`Quantidade de ${l.product.name}`}>
                <button className="qty-btn" aria-label="Diminuir quantidade" onClick={() => setQty(l.product.id, l.qty - 1)}>−</button>
                <span aria-live="polite">{l.qty}</span>
                <button className="qty-btn" aria-label="Aumentar quantidade" disabled={l.qty >= l.maxQty} onClick={() => setQty(l.product.id, l.qty + 1)}>+</button>
              </div>
              {l.qty >= l.maxQty && <p className="muted">Quantidade máxima disponível.</p>}
            </div>
            <div className="cart-side">
              <strong>{formatBRL(l.total)}</strong>
              <button className="link-btn" onClick={() => remove(l.product.id)}>Remover</button>
            </div>
          </li>
        ))}
        <li><button className="link-btn" onClick={clear}>Esvaziar carrinho</button></li>
      </ul>

      <form className="summary" onSubmit={onSubmit} noValidate>
        <h2>Resumo do pedido</h2>
        <p className="row"><span>Subtotal</span><strong>{formatBRL(subtotal)}</strong></p>
        <p className="muted">Frete: a combinar com a loja. Ele não está incluído no total.</p>

        <div className="field">
          <label htmlFor="c-nome">Seu nome *</label>
          <input id="c-nome" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" required />
        </div>
        <div className="field">
          <label htmlFor="c-cidade">Cidade de entrega *</label>
          <input id="c-cidade" value={city} onChange={(e) => setCity(e.target.value)} autoComplete="address-level2" required />
        </div>
        <div className="field">
          <label htmlFor="c-end">Endereço (se precisar de entrega)</label>
          <input id="c-end" value={address} onChange={(e) => setAddress(e.target.value)} autoComplete="street-address" />
        </div>

        {error && <p className="error" role="alert">{error}</p>}
        {!ready && (
          <p className="note" role="note">
            O WhatsApp da loja ainda não foi configurado (arquivo src/config/store.ts). Por enquanto não é possível enviar o pedido.
          </p>
        )}
        <button type="submit" className="btn btn-primary btn-lg btn-block" disabled={!ready}>
          Finalizar pelo WhatsApp
        </button>
        <p className="muted">
          Isso abre o WhatsApp com a mensagem pronta. O pedido só é enviado quando você confirmar lá, e a {storeConfig.name} confirma preço, frete e disponibilidade. Nenhum pagamento é feito neste site.
        </p>
      </form>
    </div>
  )
}

export default function CartPage() {
  usePageMeta('Carrinho')
  return (
    <div className="container section">
      <h1>Carrinho</h1>
      <CatalogGate><CartContent /></CatalogGate>
    </div>
  )
}
