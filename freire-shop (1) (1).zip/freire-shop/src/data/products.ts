import type { Product } from '../types'

/**
 * CATÁLOGO CENTRAL — edite aqui nomes, preços, descrições, imagens e categorias.
 *
 * ATENÇÃO: os itens abaixo são DEMONSTRAÇÃO (demo: true). Preços e descrições são
 * apenas exemplos de layout, não são ofertas reais. Não há estoque nem promoção
 * configurados. Para ativar:
 *   - promoPrice: 14.9         -> mostra preço promocional e a seção "Ofertas"
 *   - stock: 12                -> limita a quantidade no carrinho
 *   - available: false         -> mostra "Indisponível"
 *   - image: '/products/x.jpg' -> coloque o arquivo em public/products/
 */
export const products: Product[] = [
  // Casa e Cozinha
  { id: 'cortador-legumes', name: 'Cortador de legumes multifuncional', categoryId: 'casa-cozinha', description: 'Cortador manual para legumes e verduras. Item de demonstração: confirme modelo, material e medidas reais antes de publicar.', price: 24.9, available: true, featured: true, demo: true },
  { id: 'cortador-temperos', name: 'Cortador de temperos', categoryId: 'casa-cozinha', description: 'Utensílio para picar ervas e temperos com rapidez. Descrição de demonstração.', price: 14.9, available: true, featured: true, demo: true },
  { id: 'organizador-gavetas', name: 'Organizador de gavetas', categoryId: 'casa-cozinha', description: 'Divisórias para talheres e utensílios. Descrição de demonstração.', price: 19.9, available: true, demo: true },
  { id: 'porta-temperos', name: 'Porta-temperos giratório', categoryId: 'casa-cozinha', description: 'Suporte para manter temperos à mão. Descrição de demonstração.', price: 29.9, available: true, isNew: true, demo: true },

  // Novidades e Achadinhos
  { id: 'organizador-cabos', name: 'Organizador de cabos', categoryId: 'achadinhos', description: 'Ajuda a manter cabos e carregadores organizados. Descrição de demonstração.', price: 9.9, available: true, isNew: true, featured: true, demo: true },
  { id: 'suporte-celular', name: 'Suporte de celular dobrável', categoryId: 'achadinhos', description: 'Suporte portátil para apoiar o celular na mesa. Descrição de demonstração.', price: 12.9, available: true, isNew: true, demo: true },
  { id: 'mini-ventilador', name: 'Mini ventilador portátil', categoryId: 'achadinhos', description: 'Ventilador pequeno para uso pessoal. Descrição de demonstração.', price: 34.9, available: true, isNew: true, demo: true },
  { id: 'fita-reparos', name: 'Fita multiuso para reparos', categoryId: 'achadinhos', description: 'Solução prática para pequenos reparos. Descrição de demonstração.', price: 11.9, available: true, demo: true },

  // Automotivo e Lava-Jato
  { id: 'kit-microfibra', name: 'Kit de panos de microfibra', categoryId: 'automotivo', description: 'Panos para limpeza e secagem de veículos. Descrição de demonstração.', price: 22.9, available: true, featured: true, demo: true },
  { id: 'escova-rodas', name: 'Escova para limpeza de rodas', categoryId: 'automotivo', description: 'Escova para limpar rodas e áreas de difícil acesso. Descrição de demonstração.', price: 18.9, available: true, demo: true },
  { id: 'luva-lavagem', name: 'Luva de lavagem automotiva', categoryId: 'automotivo', description: 'Luva para aplicar shampoo e lavar o veículo. Descrição de demonstração.', price: 16.9, available: true, isNew: true, demo: true },
  { id: 'organizador-porta-malas', name: 'Organizador de porta-malas', categoryId: 'automotivo', description: 'Organizador para manter itens no lugar. Descrição de demonstração.', price: 39.9, available: true, demo: true },
]
