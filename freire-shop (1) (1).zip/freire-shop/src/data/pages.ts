import { storeConfig } from '../config/store'

export interface InfoPageContent {
  slug: string
  title: string
  description: string
  sections: { heading: string; body: string }[]
}

const n = storeConfig.name

/**
 * Textos institucionais-modelo. Trechos com [PREENCHER] precisam ser definidos por você.
 * Peça revisão profissional das páginas de privacidade e condições antes de publicar.
 */
export const infoPages: InfoPageContent[] = [
  {
    slug: 'contato',
    title: 'Contato',
    description: `Fale com a ${n}.`,
    sections: [
      { heading: 'Atendimento', body: 'Os pedidos são combinados pelo WhatsApp. Os canais e horários de atendimento ainda precisam ser informados pela loja.' },
    ],
  },
  {
    slug: 'entrega',
    title: 'Informações de entrega',
    description: 'Como funciona a entrega.',
    sections: [
      { heading: 'Entrega e frete', body: 'A disponibilidade de entrega, o valor do frete e o prazo são confirmados com a loja pelo WhatsApp, depois do pedido. Nenhum frete é cobrado automaticamente pelo site.' },
      { heading: 'Regiões atendidas', body: '[PREENCHER] Defina as cidades atendidas, formas de entrega ou retirada e prazos.' },
    ],
  },
  {
    slug: 'condicoes-de-compra',
    title: 'Condições de compra',
    description: 'Regras de compra, pagamento e trocas.',
    sections: [
      { heading: 'Como comprar', body: 'Monte o carrinho e envie o pedido pelo WhatsApp. O pedido só é considerado combinado depois da confirmação da loja. O site não processa pagamentos.' },
      { heading: 'Pagamento', body: '[PREENCHER] Informe as formas de pagamento aceitas.' },
      { heading: 'Trocas, devoluções e garantia', body: '[PREENCHER] Defina a política de trocas, devoluções e garantia, respeitando o Código de Defesa do Consumidor.' },
      { heading: 'Preços e disponibilidade', body: 'Preços e disponibilidade podem mudar e são confirmados pela loja no atendimento.' },
    ],
  },
  {
    slug: 'privacidade',
    title: 'Política de privacidade',
    description: 'Como tratamos seus dados.',
    sections: [
      { heading: 'Dados que o site usa', body: 'O carrinho fica salvo apenas no seu navegador. Nome, cidade e endereço digitados no pedido não são guardados pelo site: eles só entram no texto da mensagem que você escolhe enviar pelo WhatsApp.' },
      { heading: 'WhatsApp', body: 'Ao enviar a mensagem, os dados passam a ser tratados pelo WhatsApp e pela loja no atendimento.' },
      { heading: 'Responsável e contato', body: '[PREENCHER] Informe o responsável pelo tratamento dos dados e um contato para dúvidas (LGPD). Peça revisão profissional deste texto.' },
    ],
  },
]
