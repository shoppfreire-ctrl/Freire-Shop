import type { Category } from '../types'

/** Para criar uma nova categoria, basta adicionar um item aqui. */
export const categories: Category[] = [
  {
    id: 'casa-cozinha',
    name: 'Casa e Cozinha',
    description: 'Cortadores, utensílios, organizadores e acessórios que poupam tempo.',
    icon: '🏠',
  },
  {
    id: 'achadinhos',
    name: 'Novidades e Achadinhos',
    description: 'Produtos criativos e úteis para resolver problemas do dia a dia.',
    icon: '✨',
  },
  {
    id: 'automotivo',
    name: 'Automotivo e Lava-Jato',
    description: 'Microfibras, escovas e acessórios para cuidar do veículo.',
    icon: '🚗',
  },
  {
    id: 'moda',
    name: 'Moda',
    description: 'Roupas de fim de ano em breve.',
    icon: '👕',
    comingSoon: true,
  },
]
