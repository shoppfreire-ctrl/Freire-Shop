/**
 * CONFIGURAÇÃO ÚNICA DA LOJA
 * Tudo que for "PENDENTE" precisa ser preenchido por você antes de publicar.
 */
export const PENDING = 'PENDENTE'

export const storeConfig = {
  name: 'Freire Shop',
  slogan: 'Praticidade que cabe no seu bolso.',
  region: 'Governador Nunes Freire (MA) e cidades próximas',

  /**
   * WhatsApp comercial: somente dígitos, com código do país e DDD.
   * Exemplo: '5598912345678'. Enquanto for 'PENDENTE', o botão de pedido fica desativado.
   */
  whatsappNumber: PENDING,

  contact: {
    email: PENDING,
    instagram: PENDING,
    address: PENDING,
    hours: PENDING,
  },

  business: {
    legalName: PENDING,
    document: PENDING, // CNPJ ou CPF
  },
}

export const isPending = (value: string) =>
  value.trim() === '' || value.trim().toUpperCase() === PENDING

export const whatsappReady = () => /^\d{12,13}$/.test(storeConfig.whatsappNumber)
