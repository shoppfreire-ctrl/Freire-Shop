import { storeConfig, whatsappReady } from '../config/store'
import type { CartLine } from '../types'
import { formatBRL } from './format'

export interface OrderInfo {
  name: string
  city: string
  address: string
}

export function buildOrderMessage(lines: CartLine[], info: OrderInfo): string {
  const subtotal = lines.reduce((sum, l) => sum + l.total, 0)
  const items = lines
    .map((l) => `• ${l.qty}x ${l.product.name} — ${formatBRL(l.unitPrice)} cada = ${formatBRL(l.total)}`)
    .join('\n')

  return [
    `Olá! Gostaria de fazer um pedido na ${storeConfig.name}.`,
    '',
    items,
    '',
    `Subtotal dos produtos: ${formatBRL(subtotal)}`,
    'Frete: a combinar com a loja',
    '',
    `Nome: ${info.name.trim()}`,
    `Cidade de entrega: ${info.city.trim()}`,
    info.address.trim() ? `Endereço: ${info.address.trim()}` : 'Endereço: (a informar)',
  ].join('\n')
}

export function buildWhatsAppUrl(message: string): string | null {
  if (!whatsappReady()) return null
  return `https://wa.me/${storeConfig.whatsappNumber}?text=${encodeURIComponent(message)}`
}
