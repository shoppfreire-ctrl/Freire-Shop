import type { Product } from '../types'

const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' })
export const formatBRL = (value: number) => brl.format(value)

/** Preço promocional só vale se for realmente menor que o preço normal. */
export const hasPromo = (p: Product) =>
  typeof p.promoPrice === 'number' && p.promoPrice > 0 && p.promoPrice < p.price

export const unitPrice = (p: Product) => (hasPromo(p) ? (p.promoPrice as number) : p.price)

export const normalize = (text: string) =>
  text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim()
