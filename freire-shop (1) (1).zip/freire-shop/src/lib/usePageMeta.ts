import { useEffect } from 'react'
import { storeConfig } from '../config/store'

export function usePageMeta(title?: string, description?: string) {
  useEffect(() => {
    document.title = title
      ? `${title} — ${storeConfig.name}`
      : `${storeConfig.name} — ${storeConfig.slogan}`
    if (description) {
      document.querySelector('meta[name="description"]')?.setAttribute('content', description)
    }
  }, [title, description])
}
