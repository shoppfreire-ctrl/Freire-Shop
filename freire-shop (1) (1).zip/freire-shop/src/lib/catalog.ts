import { categories } from '../data/categories'
import { products } from '../data/products'
import type { Category, Product } from '../types'

export interface Catalog {
  products: Product[]
  categories: Category[]
}

/**
 * Hoje lê os arquivos locais. Na segunda etapa, basta trocar o corpo desta
 * função por um fetch() a uma API/banco de dados, sem mexer nas telas.
 */
export async function fetchCatalog(): Promise<Catalog> {
  return { products, categories }
}
